const firebaseConfig = {
  apiKey: "AIzaSyDQOwYHiGRd8MUu5EvJk6WkM3HxIL80zh8",
  authDomain: "frk-marketplace-6d1b9.firebaseapp.com",
  projectId: "frk-marketplace-6d1b9",
  storageBucket: "frk-marketplace-6d1b9.firebasestorage.app",
  messagingSenderId: "7157245654",
  appId: "1:7157245654:web:3b9acdf6e67fbafcf74b77"
};
